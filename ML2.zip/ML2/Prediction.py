import warnings #silences warnings
import numpy as np #math
import pandas as pd #tables and dates
from sklearn.gaussian_process import GaussianProcessRegressor #gaussian process model
from sklearn.gaussian_process.kernels import ConstantKernel as C, DotProduct, RBF, WhiteKernel #kernels for the gp
from sklearn.linear_model import BayesianRidge, Ridge #linear models
from sklearn.neural_network import MLPRegressor #neural net model

warnings.filterwarnings("ignore") #hides the warnings
THETA0 = np.array([950.0, 120.0, 850.0, 180.0, 380.0, -650.0, -9.0, 260.0, -180.0]) #true coefficients
VARY = np.array([0, 2, 3, 4, 5, 7])  #varying: const, temp bump, working, warm weekend, rain, promo
RHO_E, SD_E, CLIP = 0.70, 55.0, 80.0  #hidden event state AR(1) and the clip, as in data_gen.py
T_EVAL = 365   #forecasters warm up; errors scored from this day on
AMP, THRESH = 0.30, 1.15   #coefficients swing +-30%; "high quality" = within 1.15x the clairvoyant error
SCEN = {   #name -> (kind, speed parameter)
    "stationary": ("none", 0),
    "drift, half-life 1024 d": ("ar", 1024),
    "drift, half-life 256 d": ("ar", 256),
    "drift, half-life 64 d": ("ar", 64),
    "regimes, ~120 d": ("regime", 120),
    "regimes, ~2 d": ("regime", 2),
    "new coefficients daily": ("ar", 0),
}
HALF_LIVES = [0, 4, 16, 64, 256, 1024]   #speed sweep (0 = new coefficients every day)
FLOOR, KAL = "Floor G (no model can beat)", "Kalman (knows drift law)"   #reference rows


#generator
def rho_of(kind, param):
    """Lag-1 autocorrelation of the coefficient state: AR(param = half-life in days) or regimes (param = dwell)."""
    return 1.0 if kind == "none" else (0.0 if param <= 0 else 0.5 ** (1 / param)) if kind == "ar" else 1 - 1 / param #1 if none, 0 if new every day, else decay from half life (regimes use dwell)


def coef_path(kind, param, n, rng, k=len(VARY)):
    """Latent state z_t (n x k), zero mean and unit variance per column; regime id; regime library."""
    if kind == "none": #no change
        return np.zeros((n, k)), np.full(n, -1), None #all zeros
    if kind == "ar": #drifting coefficients
        rho, z = rho_of(kind, param), np.empty((n, k)) #decay rate and empty state
        z[0] = rng.normal(size=k) #random start
        for t in range(1, n): #each day
            z[t] = rho * z[t - 1] + np.sqrt(1 - rho ** 2) * rng.normal(size=k) #yesterdays state decayed plus new noise
        return z, np.full(n, -1), None #state, no regimes
    lib = np.column_stack([rng.permutation(np.r_[np.ones(4), -np.ones(4)]) for _ in range(k)])  # 8 balanced +-1 regimes
    r = np.empty(n, int) #regime for each day
    r[0] = rng.integers(8) #random starting regime
    for t in range(1, n): #each day
        r[t] = rng.integers(8) if rng.random() < 1 / param else r[t - 1] #switch with prob 1/param else stay
    return lib[r], r, lib #coefficients per day, regime ids, library


def generate(kind="none", param=0.0, amp=0.30, seed=1, start="2021-01-01", end="2025-12-31"):
    """theta_t = theta0 + amp*|theta0|*z_t on the 6 varying coordinates; everything else as in data_gen.py."""
    rng = np.random.default_rng(seed) #seeded random
    dates = pd.date_range(start, end, freq="D") #every day
    n = len(dates) #number of days
    angle = 2 * np.pi * (dates.dayofyear.to_numpy() - 80) / 365.25 #position in the year for seasons
    ws, ev, rain = np.zeros(n), np.zeros(n), np.zeros(n, dtype=int) #weather swing, event state, rain yes/no
    for t in range(n):                                    # same draw order as data_gen.py
        ws[t] = (0.65 * ws[t - 1] if t else 0) + rng.normal(0, 2.7) #weather noise carries over
        ev[t] = (RHO_E * ev[t - 1] if t else 0) + rng.normal(0, SD_E) #event state ar(1)
        rain[t] = rng.binomial(1, 0.15 + 0.20 * (rain[t - 1] if t else 0) + 0.04 * (1 - np.sin(angle[t]))) #rain more likely after rain and in winter
    temp = np.clip(14 + 13 * np.sin(angle) + ws, -8, 38) #seasonal temp plus weather, clipped
    humidity = np.clip(62 + 18 * rain - 0.4 * (temp - 14) + rng.normal(0, 6, n), 25, 98) #more humid when rainy and cold
    wind = np.clip(rng.gamma(2.5, 3.5, n) + 3 * rain, 1, 38) #gamma wind plus rain bump
    hol = np.isin(dates.strftime("%m-%d"), ["01-01", "07-04", "12-25"]).astype(int) #1 on jan 1, jul 4, dec 25
    work = ((dates.weekday < 5) & (hol == 0)).astype(int) #weekday and not holiday
    promo = rng.binomial(1, 0.12, n) #12% of days
    trend, wkend = np.arange(n) / 365.25, (dates.weekday >= 5) #years passed and weekend flag
    z, regime, lib = coef_path(kind, param, n, np.random.default_rng(np.random.SeedSequence([seed, 7919]))) #coefficient path with its own seed
    th = np.tile(THETA0, (n, 1)) #copy of true coefs for every day
    th[:, VARY] += amp * np.abs(THETA0[VARY]) * z #shifts only the varying ones by amp
    mean = (th[:, 0] + th[:, 1] * trend + th[:, 2] * np.exp(-((temp - 23) / 13) ** 2) + th[:, 3] * work #expected rentals = coefs x features + event
            + th[:, 4] * wkend / (1 + np.exp(-(temp - 16) / 4)) + th[:, 5] * rain + th[:, 6] * wind
            + th[:, 7] * promo + th[:, 8] * hol + ev)
    mean = np.maximum(CLIP, mean) #cant go under floor
    tau = 0.10 + 0.08 * rain #noise bigger when raining
    y = rng.poisson(mean * np.exp(rng.normal(-tau * tau / 2, tau, n))).astype(float) #poisson counts with lognormal noise
    phi = np.column_stack([np.ones(n), trend, np.exp(-((temp - 23) / 13) ** 2), work,
                           wkend / (1 + np.exp(-(temp - 16) / 4)), rain, wind, promo, hol])  # mean = phi.theta + ev
    return dict(y=y, phi=phi, X=phi[:, 1:], theta=th, z=z, regime=regime, lib=lib, ev=ev, tau=tau, #everything the models and benchmarks need
                kind=kind, param=param, amp=amp, humidity=humidity, dates=dates)


# ---------------------------------------------------------------- benchmarks
def cvar(m, tau):
    """Var(y | mean m) for the Poisson-lognormal counts."""
    return m + m * m * np.expm1(tau * tau) #poisson plus lognormal variance


def clairvoyant(d):
    """Knows theta_t exactly; tracks the hidden event state with a scalar Kalman filter."""
    base, y, n = (d["phi"] * d["theta"]).sum(1), d["y"], len(d["y"]) #coefs x features without the event part
    pred, e, p = np.empty(n), 0.0, SD_E ** 2 / (1 - RHO_E ** 2) #event guess and its variance start
    for t in range(n): #each day
        ep, pp = RHO_E * e, RHO_E ** 2 * p + SD_E ** 2 #predict event state forward
        pred[t] = max(CLIP, base[t] + ep) #forecast for the day, above floor
        k = pp / (pp + cvar(pred[t], d["tau"][t])) #kalman gain
        e, p = ep + k * (y[t] - base[t] - ep), (1 - k) * pp #update with the real y
    return pred #clairvoyant forecasts


def kalman_informed(d, rho=None):
    """Best LINEAR tracker that knows the drift law (rho, amp) and the event dynamics but NOT theta_t.  State = (z_t, e_t);
    y_t = phi_t.theta0 + sum_k phi_tk*amp*|theta0_k|*z_tk + e_t + noise.  A Kalman filter is the optimal predictor for this."""
    k, n, y, phi = len(VARY), len(d["y"]), d["y"], d["phi"] #number of varying coefs, days, rentals, features
    rho = rho_of(d["kind"], d["param"]) if rho is None else rho #drift persistence (true unless overridden)
    F = np.diag(np.r_[np.full(k, rho), RHO_E]) #state transition
    q = np.r_[np.full(k, 1 - rho ** 2), SD_E ** 2] #process noise (z has unit stationary variance)
    P = np.diag(np.r_[np.zeros(k) if d["kind"] == "none" else np.ones(k), SD_E ** 2 / (1 - RHO_E ** 2)]) #start at stationary spread
    s = np.zeros(k + 1) #state estimate
    base = phi @ THETA0 #coefs without the drift
    scale = d["amp"] * np.abs(THETA0[VARY]) #size of each coefficients swing
    pred = np.empty(n)
    for t in range(n): #each day
        sp, Pp = F @ s, F @ P @ F.T + np.diag(q) #predict state forward
        H = np.r_[phi[t, VARY] * scale, 1.0] #how the state shows up in rentals
        pred[t] = max(CLIP, base[t] + H @ sp) #forecast
        S = H @ Pp @ H + cvar(pred[t], d["tau"][t]) #innovation variance
        g = Pp @ H / S #kalman gain
        s, P = sp + g * (y[t] - base[t] - H @ sp), Pp - np.outer(g, H @ Pp) #update with real y
    return pred


def floor_g(d, S=300, seed=0):
    """F_t = Var(y_t | everything up to day t-1 incl. theta_{t-1}, e_{t-1}, all covariates), Monte Carlo over the
    one-step transition of (theta, e).  E[(y_t - yhat_t)^2] >= F_t for every forecaster using past data only."""
    rng, n, k = np.random.default_rng(seed), len(d["y"]), len(VARY) #seed, days, number of varying
    if d["kind"] == "none": #no change
        zn = np.zeros((n - 1, S, k)) #zeros
    elif d["kind"] == "ar": #drifting
        rho = rho_of("ar", d["param"]) #decay rate
        zn = rho * d["z"][:-1, None, :] + np.sqrt(1 - rho ** 2) * rng.normal(size=(n - 1, S, k)) #next day state from todays
    else: #regimes
        redraw = rng.random((n - 1, S)) < 1 / d["param"] #which samples switch regime
        zn = d["lib"][np.where(redraw, rng.integers(8, size=(n - 1, S)), d["regime"][:-1, None])] #new regime if switch else same
    sig = np.einsum("tk,tsk->ts", d["phi"][1:, VARY], zn * (d["amp"] * np.abs(THETA0[VARY]))) #effect of coefficient shift on the mean
    m = ((d["phi"][1:] @ THETA0)[:, None] + sig + RHO_E * d["ev"][:-1, None] + SD_E * rng.normal(size=(n - 1, S))) #possible means for tomorrow
    m = np.maximum(CLIP, m) #floor
    f = np.full(n, np.nan) #empty, day 0 has no past
    f[1:] = cvar(m, d["tau"][1:, None]).mean(1) + m.var(1) #noise variance + spread of means
    return f #floor G per day


def rmse(y, p):
    return float(np.sqrt(np.mean((y[T_EVAL:] - p[T_EVAL:]) ** 2))) #error after warm up


def sustained(y, p, ref, thr=1.15, win=90):
    """Share of non-overlapping 90-day windows (after warm-up) with RMSE <= thr x clairvoyant RMSE."""
    ok = [np.sqrt(np.mean((y[s:s + win] - p[s:s + win]) ** 2)) <= thr * np.sqrt(np.mean((y[s:s + win] - ref[s:s + win]) ** 2))
          for s in range(T_EVAL, len(y) - win + 1, win)] #each window passes if close enough to clairvoyant
    return float(np.mean(ok)) #fraction of windows that pass


# ---------------------------------------------------------------- forecasters
class Base:
    """Standardises features and target on the training rows [a, b).  Subclasses add fit_std and predict_std."""

    def fit(self, X, y, a, b):
        self.mu, sd = X[a:b].mean(0), X[a:b].std(0) #mean and std of features
        self.sd = np.where(sd < 1e-6, 1.0, sd) #constant column (e.g. no holiday in window)
        self.ym, self.ys = y[a:b].mean(), y[a:b].std() + 1e-9 #mean and std of target
        self.fit_std(X, y, a, b)

    def predict(self, X, y, ts):
        return self.predict_std(X, y, np.atleast_1d(ts)) * self.ys + self.ym #predictions for several days at once


class Sk(Base):
    """Any scikit-learn regressor."""

    def __init__(self, est):
        self.est = est

    def fit_std(self, X, y, a, b):
        self.est.fit((X[a:b] - self.mu) / self.sd, (y[a:b] - self.ym) / self.ys)

    def predict_std(self, X, y, ts):
        return self.est.predict((X[ts] - self.mu) / self.sd)


class LSTM(Base):
    """The last 7 days of (covariates, previous-day rentals) -> today's rentals."""
    L = 7

    def __init__(self, hidden=16, steps=35, lr=1e-2):
        self.hidden, self.steps, self.lr = hidden, steps, lr

    def _seq(self, X, y, ts):
        return np.stack([np.column_stack([(X[np.arange(t - self.L + 1, t + 1)] - self.mu) / self.sd,
                                          (y[np.arange(t - self.L, t)] - self.ym) / self.ys]) for t in ts])

    def fit_std(self, X, y, a, b):
        import torch #only loaded when needed
        torch.set_num_threads(1); torch.manual_seed(0) #one thread per worker, same result every time
        xs = torch.tensor(self._seq(X, y, range(a + self.L, b)), dtype=torch.float32)
        ys = torch.tensor((y[a + self.L:b] - self.ym) / self.ys, dtype=torch.float32)
        self.rnn, self.head = torch.nn.LSTM(xs.shape[2], self.hidden, batch_first=True), torch.nn.Linear(self.hidden, 1)
        opt = torch.optim.Adam(list(self.rnn.parameters()) + list(self.head.parameters()), lr=self.lr, weight_decay=1e-3)
        for _ in range(self.steps):
            opt.zero_grad()
            ((self.head(self.rnn(xs)[0][:, -1]).squeeze(1) - ys) ** 2).mean().backward()
            opt.step()

    def predict_std(self, X, y, ts):
        import torch
        with torch.no_grad():
            return self.head(self.rnn(torch.tensor(self._seq(X, y, ts), dtype=torch.float32))[0][:, -1]).squeeze(1).numpy()


MODELS = {  #name -> (factory, window W in days, refit every R days, first predicted day, description); settings from tuning on seeds 101/102
    "Ridge": (lambda: Sk(Ridge(alpha=5.0)), 180, 1, 180, "Linear model with a ridge penalty that shrinks the coefficients, refit every day on the last 180 days."),
    "Bayesian ridge": (lambda: Sk(BayesianRidge()), 180, 1, 180, "Linear model that chooses its own ridge penalty from the data, refit every day on the last 180 days."),
    "MLP": (lambda: Sk(MLPRegressor(hidden_layer_sizes=(32, 16), alpha=3.0, learning_rate_init=3e-3, max_iter=300, tol=1e-3,
                                    n_iter_no_change=15, random_state=0)), 300, 30, 300, "Small neural network (32 and 16 units) with a strong L2 penalty, trained on the last 300 days, refit every 30 days."),
    "Gaussian process": (lambda: Sk(GaussianProcessRegressor(DotProduct(1.0) + WhiteKernel(0.5), normalize_y=True, random_state=0)),
                         180, 30, 180, "Gaussian process with a linear kernel plus a noise term (the smooth RBF term did not help in tuning), last 180 days, refit every 30 days."),
    "LSTM": (lambda: LSTM(64, 35, 1e-2), 365, 30, 365, "64-unit recurrent network over the last 7 days of weather, calendar and yesterday's rentals, trained on the last 365 days, refit every 30 days."),
}


def walk_forward(spec, d, train_log=None):
    """Predict day t using covariates of day t and targets before t only.  The model is refit on the last W days
    (so it can follow a changing generator); an online AR(1) correction of its own residual then captures the
    hidden event state.  train_log (optional list) collects the in-sample RMSE at some refits."""
    make, W, R, t0 = spec[:4]
    X, y, n = d["X"], d["y"], len(d["y"])
    pred, model, kappa, last, sxy, sxx = np.full(n, np.nan), None, 0.0, 0.0, 0.0, 0.0 #predictions, ar(1) correction state
    for t in range(t0, n):
        if model is None or (t - t0) % R == 0: #refit when its time
            model = make()
            model.fit(X, y, t - W, t) #rows < t only
            if train_log is not None and (t - t0) % max(R, 30) == 0: #sample the training error on the rows it just learned from
                idx = np.arange(t - W + getattr(model, "L", 0), t)
                train_log.append(float(np.sqrt(np.mean((y[idx] - model.predict(X, y, idx)) ** 2))))
        base = model.predict(X, y, t)[0] #prediction from features
        pred[t] = max(0.0, base + kappa * last) #add leftover from yesterday, not below 0
        res = y[t] - base #todays miss
        sxy, sxx = 0.995 * sxy + res * last, 0.995 * sxx + last ** 2 #running sums with decay for the correlation
        kappa, last = (float(np.clip(sxy / sxx, 0, 0.95)) if sxx > 0 else 0.0), res #how much of the miss carries over (0 to .95)
    return pred
