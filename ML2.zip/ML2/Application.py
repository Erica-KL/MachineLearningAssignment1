import argparse #command line options
import os #file paths
import webbrowser #opens the web page
from concurrent.futures import ProcessPoolExecutor, as_completed #several processes at once

os.environ.setdefault("OMP_NUM_THREADS", "1") #one math thread per worker
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1") #same for numpy
import numpy as np #after the two lines above (IMPORTANT)
import pandas as pd

import webview #builds the web page
from Prediction import AMP, FLOOR, HALF_LIVES, KAL, MODELS, SCEN, T_EVAL, clairvoyant, floor_g, generate, kalman_informed, rmse, sustained, walk_forward

REPORT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "report.html") #the only output file
SWEEP_MODELS = ["Ridge", "Bayesian ridge"] #models in the speed sweep


def main_task(name, seed): #one scenario, one seed, every model
    d = generate(*SCEN[name], AMP, seed) #the time-varying series
    ref = clairvoyant(d) #knows the true coefficients
    rc, pk = rmse(d["y"], ref), kalman_informed(d) #its error; kalman filter that knows the drift law
    rows = [dict(scenario=name, seed=seed, model=FLOOR, ratio=np.sqrt(np.nanmean(floor_g(d, seed=seed)[T_EVAL:])) / rc),
            dict(scenario=name, seed=seed, model=KAL, ratio=rmse(d["y"], pk) / rc, sust=sustained(d["y"], pk, ref))]
    for m, spec in MODELS.items():
        log = [] #training errors sampled at refits
        p = walk_forward(spec, d, log) #one day at a time
        rows.append(dict(scenario=name, seed=seed, model=m, ratio=rmse(d["y"], p) / rc, sust=sustained(d["y"], p, ref), train=float(np.mean(log)), test=rmse(d["y"], p)))
    return rows


def sweep_task(hl, seed): #one drift speed, one seed
    d = generate("ar", hl, AMP, seed)
    rc = rmse(d["y"], clairvoyant(d))
    r = {FLOOR: np.sqrt(np.nanmean(floor_g(d, seed=seed)[T_EVAL:])) / rc, KAL: rmse(d["y"], kalman_informed(d)) / rc}
    r.update({m: rmse(d["y"], walk_forward(MODELS[m], d)) / rc for m in SWEEP_MODELS})
    return [dict(hl=hl, seed=seed, model=m, ratio=v) for m, v in r.items()]


def run(fn, jobs, workers, show): #runs jobs in parallel, calls show(rows so far, done, total) after each one
    rows = []
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futs = [ex.submit(fn, *j) for j in jobs]
        for i, f in enumerate(as_completed(futs), 1):
            rows += f.result()
            show(rows, i, len(futs))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=10) #seeds per scenario
    ap.add_argument("--sweep-seeds", type=int, default=5) #seeds per drift speed in the sweep
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1)) #processes (all cores but one)
    ap.add_argument("--no-open", action="store_true") #do not open the browser
    a = ap.parse_args()
    webview.render(REPORT, [], None, a, (0, a.seeds * len(SCEN))) #the page exists before the first job finishes
    print("web view: file://" + REPORT, flush=True)
    if not a.no_open: webbrowser.open("file://" + REPORT)
    main_df = run(main_task, [(n, s) for s in range(1, a.seeds + 1) for n in SCEN], a.workers, lambda rows, i, n: webview.render(REPORT, rows, None, a, (i, n)))
    sweep_df = run(sweep_task, [(h, s) for s in range(1, a.sweep_seeds + 1) for h in HALF_LIVES], a.workers, lambda rows, i, n: webview.render(REPORT, main_df, None, a, (i, n)))
    webview.render(REPORT, main_df, sweep_df, a) #final page
    print("done")
