"""Builds report.html: the benchmark table and one training/testing card per model. The same page is rewritten after every finished job (with a
progress bar and a reload script) and once more, without them, when the run is done."""
import base64
import html
import math
import numpy as np
import pandas as pd
from Prediction import AMP, FLOOR, KAL, MODELS, SCEN, THRESH, T_EVAL

esc = html.escape
CSS = """
:root{--bg:#f2f5f1;--card:#fbfcfa;--ink:#1d3345;--mute:#5d7285;--line:#d5dfd6;--sage-d:#4f7260;--sage-l:#e3ece4;--blue:#3b6ea5;--blue-l:#dce8f3;--clay:#b66a52;--clay-l:#f2e1d8}
@media (prefers-color-scheme:dark){:root{--bg:#14202b;--card:#1b2b38;--ink:#e4ecf2;--mute:#97aab9;--line:#2d4252;--sage-d:#a9c9b4;--sage-l:#223a2f;--blue:#7fb0e0;--blue-l:#1f3a52;--clay:#d98c72;--clay-l:#43302a}}
body{margin:0;background:var(--bg);color:var(--ink);font:300 17px/1.5 Oswald,'Arial Narrow',system-ui,sans-serif;letter-spacing:.01em}
.wrap{max-width:1180px;margin:0 auto;padding:0 20px 60px}
header{background:linear-gradient(135deg,var(--sage-d),var(--blue));color:#fff;padding:40px 0 30px;margin-bottom:24px}
h1{margin:0;font-weight:600;font-size:clamp(30px,5vw,50px);letter-spacing:.04em;text-transform:uppercase;line-height:1.1}
header p{margin:8px 0 0;font-size:18px;opacity:.9;max-width:760px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-top:22px}
.stats div{background:rgba(255,255,255,.14);border-radius:10px;padding:10px 14px}
.stats b{display:block;font-weight:500;font-size:28px;line-height:1.1}.stats span{font-size:13px;letter-spacing:.1em;text-transform:uppercase;opacity:.85}
.bar{background:rgba(255,255,255,.25);height:10px;border-radius:99px;margin-top:18px;overflow:hidden}.bar i{display:block;background:#fff;height:10px}
h2{font-weight:500;font-size:26px;letter-spacing:.05em;text-transform:uppercase;margin:36px 0 6px;color:var(--sage-d)}
.muted{color:var(--mute);font-size:15px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px}.card h3{margin:0 0 4px;font-weight:500;font-size:20px}
.grid{display:grid;gap:16px;grid-template-columns:repeat(auto-fill,minmax(min(100%,420px),1fr))}
.scroll{overflow-x:auto;border:1px solid var(--line);border-radius:14px;background:var(--card)}
table{border-collapse:collapse;width:100%;font-size:15px}th,td{padding:8px 12px;text-align:right;white-space:nowrap}
th{font-weight:500;font-size:13px;letter-spacing:.07em;text-transform:uppercase;color:var(--mute);border-bottom:1px solid var(--line);vertical-align:bottom;white-space:normal;min-width:96px}
th:first-child,td:first-child{text-align:left;position:sticky;left:0;background:var(--card);min-width:210px;font-weight:400}
tr.ref td{font-style:italic;color:var(--mute)}td small{display:block;font-size:11px;opacity:.65}
.badge{padding:2px 10px;border-radius:99px;font-size:12px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap}
.ok{background:var(--sage-l);color:var(--sage-d)}.law{background:var(--blue-l);color:var(--blue)}.no{background:var(--clay-l);color:var(--clay)}.open{background:var(--line);color:var(--mute)}
.chip{display:inline-block;background:var(--sage-l);color:var(--sage-d);border-radius:8px;padding:1px 10px;margin:8px 8px 4px 0;font-size:13px}
.kv{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0}.kv div{background:var(--bg);border-radius:10px;padding:6px 10px}
.kv b{display:block;font-weight:500;font-size:22px;line-height:1.15}.kv span{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--mute)}
.mini th,.mini td{padding:3px 6px;font-size:14px;min-width:0;position:static;background:none;white-space:normal}.mini .pill{padding:0 8px;border-radius:6px}
summary{cursor:pointer;color:var(--blue)}a{color:var(--blue)}
"""
FONT = "<link href='https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600&display=swap' rel='stylesheet'>"


def pill(r):
    """Cell colour: sage inside the bar (greener = closer to clairvoyant), clay outside (deeper = worse), grey while waiting."""
    if r != r: return "color:var(--mute)"
    t, (c0, c1) = ((r - 1) / (THRESH - 1), ((190, 218, 199), (230, 239, 231))) if r <= THRESH else ((r - THRESH) / (2 - THRESH), ((244, 228, 217), (214, 148, 122)))
    return "background:rgb%s;color:#1d3345" % (tuple(round(a + (b - a) * min(max(t, 0), 1)) for a, b in zip(c0, c1)),)


def crossing(hl, v):
    """Half-life at which a curve first drops under the bar (interpolated on a log axis; 0 counts as 0.5)."""
    x = [h or 0.5 for h in hl]
    for i in range(len(x) - 1):
        if v[i] > THRESH >= v[i + 1]:
            return math.exp(math.log(x[i]) + (v[i] - THRESH) / (v[i] - v[i + 1]) * (math.log(x[i + 1]) - math.log(x[i])))
    return float("nan")


def render(path, df, sw, a, prog=None):
    """df: result rows so far; sw: speed-sweep rows (final page only); prog: (jobs done, total) while running, None at the end."""
    df = pd.DataFrame(df).reindex(columns=["model", "scenario", "ratio", "sust", "train", "test"])
    sc, ms = list(SCEN), list(MODELS)
    ci = lambda x: 1.96 * x.std() / len(x) ** .5
    def tab(col, f="mean", rows=ms):
        t = df.pivot_table(index="model", columns="scenario", values=col, aggfunc=f) if df[col].notna().any() else pd.DataFrame()
        return t.reindex(index=rows, columns=sc)
    mean, err, sus, train, test = tab("ratio", rows=[FLOOR, KAL] + ms), tab("ratio", ci, [FLOOR, KAL] + ms), tab("sust"), tab("train"), tab("test")
    f = lambda v, spec: f"{v:{spec}}" if v == v else "…"

    def verdict(c):
        fl, k, b = mean.loc[FLOOR, c], mean.loc[KAL, c], mean.loc[ms, c].min()
        if prog or np.isnan([fl, k, b]).any(): return "…", "open"
        return ("Not learnable", "no") if fl > THRESH else ("Learnable", "ok") if b <= THRESH else ("Only if law known", "law") if k <= THRESH else ("Open", "open")
    verd = {c: verdict(c) for c in sc}

    def row(m, cls=""):
        return f"<tr class='{cls}'><td>{esc(m)}</td>" + "".join(
            f"<td style='{pill(mean.loc[m, c])}' title='95% CI ± {f(err.loc[m, c], '.3f')}'>{f(mean.loc[m, c], '.3f')}<small>± {f(err.loc[m, c], '.3f')}</small></td>" for c in sc) + "</tr>"
    cross = ""
    if sw is not None:
        s = sw.pivot_table(index="hl", columns="model", values="ratio")
        cross = "<p class='muted'>Slowest drift (half-life) each curve can handle within the bar: " + ", ".join(
            f"{esc(m.split(' (')[0])} {f(crossing(list(s.index), s[m].to_numpy()), '.0f')} d" for m in s.columns) + ".</p>"
    bench = ("<h2>Benchmark</h2><p class='muted'>Mean over seeds, 95% interval underneath. Sage cells are within the bar, clay cells are not. <i>Floor G</i> is the best any forecaster using "
             "past data could do; <i>Kalman</i> is the best linear tracker that is told how the coefficients drift.</p><div class='scroll'><table><tr><th>model</th>"
             + "".join(f"<th>{esc(c)}</th>" for c in sc) + "</tr>" + row(FLOOR, "ref") + row(KAL, "ref") + "".join(row(m) for m in ms)
             + "<tr><td>Verdict</td>" + "".join(f"<td><span class='badge {v[1]}'>{v[0]}</span></td>" for v in verd.values()) + "</tr></table></div>" + cross)

    cards = []
    for m, spec in MODELS.items():
        W, R = spec[1], spec[2]
        tr, te = train.loc[m].mean(), test.loc[m].mean()
        by = "".join(f"<tr><td>{esc(c)}</td><td>{f(train.loc[m, c], '.0f')}</td><td>{f(test.loc[m, c], '.0f')}</td><td><span class='pill' style='{pill(mean.loc[m, c])}'>{f(mean.loc[m, c], '.3f')}</span></td>"
                     f"<td>{f(100 * sus.loc[m, c], '.0f')}%</td></tr>" for c in sc)
        cards.append(
            f"<div class='card'><h3>{esc(m)}</h3><p class='muted' style='margin:0'>{esc(spec[4])}</p><span class='chip'>trains on last {W} days</span>"
            f"<span class='chip'>{'one fit, never refit' if R > 10**6 else 'refit daily' if R == 1 else f'refit every {R} days'}</span>"
            f"<div class='kv'><div><b>{f(tr, '.0f')}</b><span>training RMSE</span></div><div><b>{f(te, '.0f')}</b><span>test RMSE</span></div>"
            f"<div><b>{f(te / tr, '.2f')}</b><span>test ÷ train</span></div><div><b>{int((mean.loc[m] <= THRESH).sum())}/{len(sc)}</b><span>scenarios in bar</span></div></div>"
            f"<details><summary>By scenario</summary><table class='mini'><tr><th>scenario</th><th>train RMSE</th><th>test RMSE</th><th>error ratio</th><th>windows in bar</th></tr>{by}</table></details></div>")
    models_sec = ("<h2>Training vs testing</h2><p class='muted'>RMSE in rentals per day, averaged over the scenarios. Training error is on the days a model was fit on, test error on days it "
                  "had not seen. “Windows in bar” is the share of 90-day stretches of the test period that stay within the bar.</p><div class='grid'>" + "".join(cards) + "</div>")

    stats = ([(f"{prog[0]} / {prog[1]}", "jobs done")] if prog else
             [(len(ms), "models"), (len(sc), "scenarios"), (a.seeds, "seeds"), (f"{sum(v[1] == 'ok' for v in verd.values())} / {sum(v[1] == 'no' for v in verd.values())}", "learnable / not")])
    top = ("<header><div class='wrap'><h1>Forecasting benchmark</h1><p>Five forecasters against seven versions of the bike-rental generator. Every score is RMSE divided by the "
           "clairvoyant RMSE (a forecaster that knows the true coefficients), so 1.00 is perfect and 1.15 is the quality bar.</p><div class='stats'>"
           + "".join(f"<div><b>{v}</b><span>{k}</span></div>" for v, k in stats) + "</div>"
           + (f"<div class='bar'><i style='width:{100 * prog[0] / prog[1]:.0f}%'></i></div>" if prog else "") + "</div></header>")
    foot = (f"<p class='muted' style='margin-top:30px'>Each scenario is a 1,826-day series. The first {T_EVAL} days are warm-up and not scored; the other {1826 - T_EVAL:,} are forecast one "
            f"day ahead, and a model only ever trains on days before the one it forecasts. Coefficients swing ±{int(AMP * 100)}%. "
            f"<a download='results.csv' href='data:text/csv;base64,{base64.b64encode(df.to_csv(index=False).encode()).decode()}'>Download raw results (csv)</a></p>")
    reload = ("<script>try{scrollTo(0,+sessionStorage.sy||0)}catch(e){}setTimeout(function(){try{sessionStorage.sy=scrollY}catch(e){}location.reload()},2000)</script>" if prog else "")
    open(path, "w").write(f"<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Forecasting benchmark</title>{FONT}"
                          f"<style>{CSS}</style>{top}<div class='wrap'>{bench}{models_sec}{foot}</div>{reload}")
