from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd


def generate_data(seed: int = 20260909, start: str = "2021-01-01",
                  end: str = "2023-12-31") -> tuple[pd.DataFrame, pd.DataFrame]:
    """Generate a fictional daily sequence of bike rental counts and other features.

    Rental counts are Poisson-lognormal with mean ``mean_demand`` conditional
    on realized current weather and the hidden event state. The two-stage
    sampling keeps counts nonnegative and produces overdispersion.
    Dates/holidays/promotions describe a fictional operator, not actual records.
    """
    rng = np.random.default_rng(seed)
    dates = pd.date_range(start, end, freq="D")
    n = len(dates)
    if n < 120:
        raise ValueError("Generate at least 120 consecutive days.")
    angle = 2 * np.pi * (dates.dayofyear.to_numpy() - 80) / 365.25
    weather_state = np.zeros(n)
    latent_event = np.zeros(n)
    rain = np.zeros(n, dtype=int)
    for t in range(n):
        weather_state[t] = (0.65 * weather_state[t-1] if t else 0) + rng.normal(0, 2.7)
        latent_event[t] = (0.70 * latent_event[t-1] if t else 0) + rng.normal(0, 55)
        wet_probability = 0.15 + 0.20 * (rain[t-1] if t else 0) + 0.04 * (1-np.sin(angle[t]))
        rain[t] = rng.binomial(1, wet_probability)
    temp = np.clip(14 + 13 * np.sin(angle) + weather_state, -8, 38)
    humidity = np.clip(62 + 18*rain - 0.4*(temp-14) + rng.normal(0, 6, n), 25, 98)
    wind = np.clip(rng.gamma(2.5, 3.5, n) + 3*rain, 1, 38)
    # Fictional, scheduled special days; not an authoritative holiday calendar.
    # TODO: could add more holidays, e.g., Thanksgiving, Labor Day, etc.
    holiday = np.isin(dates.strftime("%m-%d"), ["01-01", "07-04", "12-25"]).astype(int)
    working = ((dates.weekday < 5) & (holiday == 0)).astype(int)
    promotion = rng.binomial(1, 0.12, n)  # assumed announced before the forecast
    trend = np.arange(n) / 365.25
    mean = (950 + 120*trend + 850*np.exp(-((temp-23)/13)**2) + 180*working
            + 380*(dates.weekday >= 5)/(1+np.exp(-(temp-16)/4))
            - 650*rain - 9*wind + 260*promotion - 180*holiday + latent_event)
    mean = np.maximum(80, mean)
    tau = 0.10 + 0.08*rain
    multiplier = np.exp(rng.normal(-tau*tau/2, tau, n))
    rentals = rng.poisson(mean*multiplier)
    observed = pd.DataFrame({"date": dates, "temp_c": temp, "rain": rain,
        "humidity_pct": humidity, "wind_kmh": wind, "holiday": holiday,
        "promotion": promotion, "rentals": rentals})
    truth = pd.DataFrame({"date": dates, "mean_demand": mean,
        "latent_event": latent_event, "noise_multiplier": multiplier, "lognoise_sd": tau})
    return observed, truth


def validate_raw(raw: pd.DataFrame, allow_unknown_last_target: bool = False) -> pd.DataFrame:
    """Validate a daily sequence; do not silently sort, interpolate, or fill targets."""
    required = {"date", "temp_c", "rain", "humidity_pct", "wind_kmh",
                "holiday", "promotion", "rentals"}
    missing = required - set(raw.columns)
    if missing:
        raise ValueError(f"Missing raw columns: {sorted(missing)}")
    df = raw.copy()
    df["date"] = pd.to_datetime(df["date"], errors="raise")
    if df["date"].duplicated().any() or not df["date"].is_monotonic_increasing:
        raise ValueError("Dates must be unique and increasing.")
    if not df["date"].diff().dropna().eq(pd.Timedelta(days=1)).all():
        raise ValueError("Dates must be consecutive daily observations.")
    target = df["rentals"].iloc[:-1] if allow_unknown_last_target else df["rentals"]
    if target.isna().any() or not np.isfinite(target.to_numpy(dtype=float)).all() or (target < 0).any():
        raise ValueError("Observed rental counts must be finite and nonnegative.")
    return df
