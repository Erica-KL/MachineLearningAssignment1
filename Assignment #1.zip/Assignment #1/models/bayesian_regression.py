
##Side note: found this book https://www.bayesrulesbook.com/chapter-9#building-the-regression-model
##and its been very helpful it explains it very simply and has quizzes and stuff.


import numpy as np #numerical operations
from sklearn.linear_model import BayesianRidge #import the model from sci kit

NAME = "Bayesian Linear Regression" #name of model


def run(X_train, y_train, X_test, y_test, feature_names): #def for training/testing
    model = BayesianRidge() #model is bayesianridge
    model.fit(X_train, y_train) #fits the model so it can understand the data trend and adjust bias

    y_pred, y_std = model.predict(X_test, return_std=True) #predicts values and standard deviation
    y_pred_train = model.predict(X_train) #predict on training data itself
    train_mae = float(np.mean(np.abs(y_pred_train - y_train))) #training error


    weight_summary = { #for display
        name: {"mean": float(coef), "std": float(std)} #top row
        for name, coef, std in zip(feature_names, model.coef_, model.sigma_.diagonal() ** 0.5) #display the names
    }

    return { #return results cleanly
        "y_pred": y_pred, #predicted average y value
        "train_mae": train_mae, #average error on training data
        "y_std": y_std, #predicted standard deviation
        "intercept": float(model.intercept_), #estimated intercept where x=0
        "weight_summary": weight_summary,
        "alpha_": float(model.alpha_),   #noise precision (1/variance), not likelihood
        "lambda_": float(model.lambda_),  #precision of the weight prior, not the weight itself
    }
