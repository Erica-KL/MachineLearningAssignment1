

import numpy as np #import number calculation
from sklearn.gaussian_process import GaussianProcessRegressor #import model 
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel #certain skills like distance measuring and noise 
from sklearn.preprocessing import StandardScaler #import data scaler

NAME = "Gaussian Process Regression" #name of model


def run(X_train, y_train, X_test, y_test, feature_names): #def for training/testing

    scaler = StandardScaler() #define scaler
    X_train_scaled = scaler.fit_transform(X_train) #fit training data to scaler transform it (puts every feature on the same scale so no one feature dominates distance)
    X_test_scaled = scaler.transform(X_test) #transform to scaler


    kernel = ( #bell curve similarity, not a parabola
        ConstantKernel(1.0, constant_value_bounds=(1e-2, 1e3)) #min/max

        * RBF(length_scale=np.ones(X_train.shape[1]), length_scale_bounds=(1e-2, 1e3)) #distance and bounds 
        + WhiteKernel(noise_level=1.0, noise_level_bounds=(1e-3, 1e3)) #noise level and bounds
    )

    model = GaussianProcessRegressor(
        kernel=kernel, #kernel is kernel
        normalize_y=True, #normalize target y 
        n_restarts_optimizer=5,  #restart kernel-hyperparameter search from
                                  #a few random starting points, since it's
                                  #a nonconvex optimization
        random_state=0,
    )
    model.fit(X_train_scaled, y_train) #model learns trends from daily.csv

    y_pred, y_std = model.predict(X_test_scaled, return_std=True)
    y_pred_train = model.predict(X_train_scaled) #predict on training data itself
    train_mae = float(np.mean(np.abs(y_pred_train - y_train))) #training error

    fitted_length_scales = model.kernel_.k1.k2.length_scale #get fitted length scales from kernel
    length_scale_summary = { #length scale 
        name: float(ls) for name, ls in zip(feature_names, np.atleast_1d(fitted_length_scales)) #display
    }

    return {
        "y_pred": y_pred, #return y predictions
        "train_mae": train_mae, #average error on training data
        "y_std": y_std, #return y stand dev
        "length_scale_summary": length_scale_summary, #return length scale summary 
        "fitted_kernel": str(model.kernel_), #return fitted kernel
    }
