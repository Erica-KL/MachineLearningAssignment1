
import numpy as np #import numerical operations #import numerical operations
from sklearn.linear_model import RidgeCV #import ridge regression 
from sklearn.model_selection import TimeSeriesSplit #time series split 

NAME = "Linear Regression (Ridge)" #name of model 

ALPHA_CANDIDATES = np.logspace(-3, 3, 13)  #range of alpha values


def run(X_train, y_train, X_test, y_test, feature_names): #def for training/testing 
    time_aware_cv = TimeSeriesSplit(n_splits=5) #time series split with 5 splits 
    model = RidgeCV(alphas=ALPHA_CANDIDATES, cv=time_aware_cv) #ridge regression with cross validation 
    model.fit(X_train, y_train) #fit model to training data ~nuance~

    y_pred = model.predict(X_test) #predict y values
    y_pred_train = model.predict(X_train) #predict on training data itself
    train_mae = float(np.mean(np.abs(y_pred_train - y_train))) #training error

    coef_summary = { #one coefficient per feature, not a sum
        name: float(coef) for name, coef in zip(feature_names, model.coef_) #display
    }

    return {
        "y_pred": y_pred,#predictions of y
        "train_mae": train_mae, #average error on training data
        "intercept": float(model.intercept_), #the intercept
        "coef_summary": coef_summary, #one coefficient per feature, not a sum
        "chosen_alpha": float(model.alpha_), #final alpha value
    }
