import numpy as np #numerical operations
import torch #torch lib
import torch.nn as nn #nueral network library 
from sklearn.preprocessing import StandardScaler #standard scaler 

NAME = "LSTM (Recurrent Neural Network)" #name of model 

SEQUENCE_LENGTH = 14  #time span of 14 days 
HIDDEN_SIZE = 32 #no. of nuerons 
EPOCHS = 200 #data set exposure
LEARNING_RATE = 1e-3 #learning rate for gradient 


def build_windows(X, y, seq_len): #data windows 

    n = len(X) #number of rows in X
    X_windows = np.stack([X[i:i + seq_len] for i in range(n - seq_len)]) #stacking the windows
    
    y_windows = y[seq_len:] #window target the day after the window
    return X_windows, y_windows #return the windows and targets 


class LSTMRegressor(nn.Module): 
    def __init__(self, n_features, hidden_size=HIDDEN_SIZE): #initialize the model 
        super().__init__()  
        self.lstm = nn.LSTM(input_size=n_features, hidden_size=hidden_size, batch_first=True) #LSTM layer 
        self.head = nn.Linear(hidden_size, 1) #hidden layer to output layer

    def forward(self, x): 
        # x: (batch, seq_len, n_features)
        _, (h_n, _) = self.lstm(x)     #self lstm layer 

        return self.head(h_n.squeeze(0)).squeeze(-1)  #neural network output layer 


def run(X_train, y_train, X_test, y_test, feature_names): #def for training/testing 
    torch.manual_seed(0) #torch defined random seed 

    x_scaler = StandardScaler().fit(X_train) #standard scaler fit to training data 
    y_scaler = StandardScaler().fit(y_train.reshape(-1, 1)) #standard scaler fit to training target data.

    X_train_scaled = x_scaler.transform(X_train) #transforms training data
    X_test_scaled = x_scaler.transform(X_test) #transforms test data
    y_train_scaled = y_scaler.transform(y_train.reshape(-1, 1)).flatten() #tranforms target data
    y_test_scaled = y_scaler.transform(y_test.reshape(-1, 1)).flatten() #transforms test target data

    X_all = np.vstack([X_train_scaled, X_test_scaled]) #stack training and test data 
    y_all = np.concatenate([y_train_scaled, y_test_scaled]) #concatenate training and test data 
    X_windows, y_windows = build_windows(X_all, y_all, SEQUENCE_LENGTH) #windows of training and test sequence length.


    target_idx = np.arange(len(y_windows)) + SEQUENCE_LENGTH #target length for each window 
    train_mask = target_idx < len(X_train) #mask for training data
    test_mask = ~train_mask #test mask is the opposite

    X_train_win = torch.tensor(X_windows[train_mask], dtype=torch.float32) #training data windows 
    y_train_win = torch.tensor(y_windows[train_mask], dtype=torch.float32) #training target windows 
    X_test_win = torch.tensor(X_windows[test_mask], dtype=torch.float32) #test data windows 

    n_features = X_train.shape[1] #number of features in training data
    model = LSTMRegressor(n_features) #initialize the model 
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE) #optimizer is torch adam
    loss_fn = nn.MSELoss() #mean squared error loss function 


    train_curve = [] #list to store training loss 
    model.train() #set model to training mode 
    for epoch in range(EPOCHS): #loop of epochs
        optimizer.zero_grad() #zero the gradients 
        y_hat = model(X_train_win) #vector of predictions for each window 
        loss = loss_fn(y_hat, y_train_win) #compute loss between predictions and true values
        loss.backward() #compute gradients 
        optimizer.step() #optimizer adam steps 
        train_curve.append((epoch, float(loss.item()))) #append epoch and loss to training curve 

    model.eval() #evaluation mode
    with torch.no_grad(): #disable gradient compute
        y_pred_scaled = model(X_test_win).numpy() #y predictions scaled to standard scaler
        y_pred_train_scaled = model(X_train_win).numpy() #predict on the training windows themselves

    # Undo the scaling so predictions come back in real rental-count units.
    y_pred = y_scaler.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten() #inverse scaler
    y_pred_train = y_scaler.inverse_transform(y_pred_train_scaled.reshape(-1, 1)).flatten() #back to real units
    y_train_actual = y_scaler.inverse_transform(y_train_win.numpy().reshape(-1, 1)).flatten() #real actual training targets
    train_mae = float(np.mean(np.abs(y_pred_train - y_train_actual))) #training error, over the 747 training windows

    assert len(y_pred) == len(y_test), "every test day should get exactly one prediction" #asert to test

    return {
        "y_pred": y_pred, #predicted y values
        "train_mae": train_mae, #average error on training windows
        "train_curve": train_curve,  #list of training loss per epoch
    }
