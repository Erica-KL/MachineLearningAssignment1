

import numpy as np #numerical operations
from sklearn.neural_network import MLPRegressor #mlp regresser
from sklearn.preprocessing import StandardScaler #standard scaler

NAME = "MLP (Neural Network)" #name of model

HIDDEN_LAYER_SIZES = (64, 32) #2 layers 64, and then 32
MAX_ITER = 500 #maxiumun number of iterations


def run(X_train, y_train, X_test, y_test, feature_names): #def for training/testing 

    x_scaler = StandardScaler().fit(X_train) #standard scaler fit to training data
    y_scaler = StandardScaler().fit(y_train.reshape(-1, 1))

    X_train_scaled = x_scaler.transform(X_train) #transforms training data
    X_test_scaled = x_scaler.transform(X_test) #tranforms test data 
    y_train_scaled = y_scaler.transform(y_train.reshape(-1, 1)).flatten() #transforms target data

    model = MLPRegressor( 
        hidden_layer_sizes=HIDDEN_LAYER_SIZES, #hidden layer sizes 
        activation="relu", #relu
        solver="adam",          #adam is the optimizer
                                 
        max_iter=MAX_ITER, #maximum number of iterations
        random_state=0, #determined random seed for reproducibility 
    )
    model.fit(X_train_scaled, y_train_scaled) #fit model to training data 

    y_pred_scaled = model.predict(X_test_scaled) #model predicts y values scaled to standarad scaler 

    y_pred = y_scaler.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten() #inverse transformation to get back to original scale

    y_pred_train_scaled = model.predict(X_train_scaled) #predict on training data itself
    y_pred_train = y_scaler.inverse_transform(y_pred_train_scaled.reshape(-1, 1)).flatten() #back to real units
    train_mae = float(np.mean(np.abs(y_pred_train - y_train))) #training error

    train_curve = list(enumerate(model.loss_curve_))  #list of training loss per epcoch

    return {
        "y_pred": y_pred, #y prediction
        "train_mae": train_mae, #average error on training data
        "train_curve": train_curve,  #list of training loss per epoch
    }
