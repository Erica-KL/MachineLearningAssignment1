import os
import webbrowser
import numpy as np
import pandas as pd

from models import linear_regression, bayesian_regression, gaussian_process, lstm, mlp

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
DATA_PATH = "daily.csv"  #database
OUTPUT_DIR = "output" #output 
REPORT_PATH = os.path.join(OUTPUT_DIR, "report.html") #put output in nice format

os.makedirs(OUTPUT_DIR, exist_ok=True) #if it exists


# ---------------------------------------------------------------------------
 #HTML report
# ---------------------------------------------------------------------------

REPORT_SECTIONS = [] 


def section(title, html_body):  
    REPORT_SECTIONS.append(f"<h2>{title}</h2>\n{html_body}\n")


def df_to_html_table(df, max_rows=10): 
    return df.head(max_rows).to_html(index=False, border=1)


def write_report(): #headline design 
    html = f"""<!DOCTYPE html> 
<html>
<head>
<meta charset="UTF-8">
<title>Bike Rental Forecasting</title>
<style>
    body {{ font-family: "Letter Gothic Std", monospace; background-color: #fefbea; }}
    h1, h2, h3 {{ text-align: center; }}
</style>
</head>
<body>
<h1>Bike Rental Forecasting</h1>

{''.join(REPORT_SECTIONS)}

</body>
</html>
"""
    with open(REPORT_PATH, "w") as f: #path to html 
        f.write(html)
    print(f"Report written to {REPORT_PATH}")
    webbrowser.open(f"file://{os.path.abspath(REPORT_PATH)}")


# ---------------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------------
def load_data(): #data read, parse, load 
    df = pd.read_csv(DATA_PATH, parse_dates=["date"])
    return df


# ---------------------------------------------------------------------------
# Data overview (not yet a numbered assignment part - just a sanity check)
# ---------------------------------------------------------------------------
def section_data_overview(df): #upper data display 
    body = f"""
    <h3>First rows</h3>
    {df_to_html_table(df, max_rows=5)}
    <h3>Summary statistics</h3>
    {df.describe().round(2).to_html(border=1)}
    """
    section("Data Overview", body)


# ---------------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------------
def check_data_quality(df): #quality checks
    """Run basic sanity checks. Returns a list of (check, result, ok) tuples."""
    full_range = pd.date_range(df["date"].min(), df["date"].max(), freq="D")
    checks = [
        ("Missing values (any column)", int(df.isna().sum().sum()), 0),
        ("Duplicate dates", int(df["date"].duplicated().sum()), 0),
        ("Missing calendar days", len(full_range) - len(df), 0),
        ("Rentals <= 0", int((df["rentals"] <= 0).sum()), 0),
        ("Humidity outside 0-100%", int(((df["humidity_pct"] < 0) | (df["humidity_pct"] > 100)).sum()), 0),
        ("Negative wind speed", int((df["wind_kmh"] < 0).sum()), 0),
        ("rain not in {0,1}", int((~df["rain"].isin([0, 1])).sum()), 0),
        ("holiday not in {0,1}", int((~df["holiday"].isin([0, 1])).sum()), 0),
        ("promotion not in {0,1}", int((~df["promotion"].isin([0, 1])).sum()), 0),
    ]
    return [(name, val, val == expected) for name, val, expected in checks]


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------

FEATURE_COLUMNS = [ #features 
    "temp_c", "rain", "humidity_pct", "wind_kmh", "holiday", "promotion",
    "day_of_week", "month", "is_weekend",
    "rentals_lag_1", "rentals_lag_7", "rentals_roll_mean_7",
]
TARGET_COLUMN = "rentals"


def add_features(df): 
  
    df = df.sort_values("date").reset_index(drop=True)

    df["day_of_week"] = df["date"].dt.dayofweek  # 0=Monday ... 6=Sunday
    df["month"] = df["date"].dt.month
    df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)

    df["rentals_lag_1"] = df["rentals"].shift(1)   #yesterday's rentals
    df["rentals_lag_7"] = df["rentals"].shift(7)   #same weekday, last week
    df["rentals_roll_mean_7"] = df["rentals"].shift(1).rolling(7).mean()

    n_before = len(df)
    df = df.dropna().reset_index(drop=True)
    n_dropped = n_before - len(df)
    return df, n_dropped


def split_chronologically(df, train_frac=0.7, val_frac=0.15): 

    n = len(df)
    train_end = int(n * train_frac)
    val_end = int(n * (train_frac + val_frac))
    train_df = df.iloc[:train_end].reset_index(drop=True)
    val_df = df.iloc[train_end:val_end].reset_index(drop=True)
    test_df = df.iloc[val_end:].reset_index(drop=True)
    return train_df, val_df, test_df


def to_X_y(df):

    X = df[FEATURE_COLUMNS].to_numpy(dtype=float)
    y = df[TARGET_COLUMN].to_numpy(dtype=float)
    return X, y


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
MODEL_MODULES = [linear_regression, bayesian_regression, gaussian_process, lstm, mlp]


def run_all_models(X_train, y_train, X_test, y_test, feature_names):
    results = []
    for module in MODEL_MODULES:
        result = module.run(X_train, y_train, X_test, y_test, feature_names)
        mae = float(np.mean(np.abs(np.asarray(result["y_pred"]) - y_test)))
        results.append((module.NAME, result, mae))
    return results


def section_models(results, y_test):
    blocks = []
    for name, result, mae in results:
        y_pred = result["y_pred"]
        preview_rows = "".join(
            f"<tr><td>{actual:.0f}</td><td>{pred:.0f}</td></tr>"
            for actual, pred in zip(y_test[:5], y_pred[:5])
        )

        extras = [f"<p>Average margin of error: {mae:.1f} rentals</p>"]
        if "train_mae" in result:
            extras.append(f"<p>Training error: {result['train_mae']:.1f} rentals</p>")
        if "y_std" in result:
            extras.append(f"<p>Mean predictive std: {np.mean(result['y_std']):.1f}</p>")
        if "chosen_alpha" in result:
            extras.append(f"<p>Chosen alpha: {result['chosen_alpha']:.4g}</p>")
        if "coef_summary" in result:
            extras.append("<p>Coefficients: " + ", ".join(
                f"{k}={v:.2f}" for k, v in result["coef_summary"].items()) + "</p>")
        if "weight_summary" in result:
            extras.append("<p>Weights (mean&plusmn;std): " + ", ".join(
                f"{k}={v['mean']:.2f}&plusmn;{v['std']:.2f}"
                for k, v in result["weight_summary"].items()) + "</p>")
        if "length_scale_summary" in result:
            extras.append("<p>Length scales: " + ", ".join(
                f"{k}={v:.2f}" for k, v in result["length_scale_summary"].items()) + "</p>")
        if "train_curve" in result:
            last_loss = result["train_curve"][-1][1]
            extras.append(
                f"<p>Final training loss: {last_loss:.4f} "
                f"(over {len(result['train_curve'])} steps)</p>")

        blocks.append(f"""
        <h3>{name}</h3>
        <table border="1">
            <tr><th>Actual</th><th>Predicted</th></tr>
            {preview_rows}
        </table>
        {''.join(extras)}
        """)

    section("Models", "".join(blocks))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    df = load_data()
    section_data_overview(df)

    featured_df, n_dropped = add_features(df)
    train_df, val_df, test_df = split_chronologically(featured_df)

    X_train, y_train = to_X_y(train_df)
    X_val, y_val = to_X_y(val_df)
    X_test, y_test = to_X_y(test_df)

    results = run_all_models(X_train, y_train, X_test, y_test, FEATURE_COLUMNS)
    section_models(results, y_test)


    write_report()


if __name__ == "__main__":
    main()
